#ifndef __MPU6050_H
#define __MPU6050_H

#include "stm32f10x.h" 
#include "SoftwareI2C.h"
#define MPU6050_ADDRESS	0xD0

//指定地址写寄存器数据
void MPU6050_WriteReg(uint8_t RegAddress, uint8_t Data);
//指定地址读寄存器数据
uint8_t MPU6050_ReadReg(uint8_t RegAddress);
void MPU6050_Init(void);
uint8_t  MPU6050_GetID(void);
void MPU6050_GetData(int16_t* AccX, int16_t* AccY, int16_t* AccZ,
					 int16_t* GyroX,int16_t* GyroY,int16_t* GyroZ);
#endif
